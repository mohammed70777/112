# StringArtGenerator
Web based string art generator

This project is heavily based on the work of reddit user /u/kmmeerts from his post: https://www.reddit.com/r/DIY/comments/au0ilz/made_a_string_art_portrait_out_of_a_continuous_2/


To use ths generator, navigate to: https://halfmonty.github.io/StringArtGenerator/

![](test2.gif)
